<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="/bootstrap/css/bootstrap.css">
</head>
<body>
<?php
$input = $_GET['input']??null;
$msg = $_GET['msg']??null;
$email_class = null;
$first_name_class = null;
if ($input=='email'){
    $email_class = "error";
}
if ($input=='first_name'){
    $first_name_class = "error";
}
?>
<div class="container-fluid">
    <form action="login.php" method="post">
        <h3>Contact Us</h3>
        <?php
        if ($input){
        ?>
        <div class="alert alert-danger">
            <?php echo $msg;?>
        </div>
        <?php
        }
        ?>
        <p><label>First Name: <input class="<?php echo $first_name_class; ?>"  name="first_name" type="text" placeholder="Your First Name" value=""></label></p>
        <p><label>Last Name: <input name="last_name" type="text" placeholder="Your Last Name" value=""></label></p>
        <p><label>Email: <input class="<?php echo $email_class; ?>" name="email" type="text" placeholder="Your Email"></label></p>
        <p><label>Phone number: <input name="phone" type="text" placeholder="Your Phone Number"></label></p>
        <p>
            <button type="reset">Reset</button>
            <button type="submit">Submit</button>
        </p>
    </form>
</div>
<style>
    .error{
        border: 2px solid red;
        background-color: #ededa8;
        color: darkblue;
    }
</style>
</body>
</html>